var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/resend-confirmation/route.js")
R.c("server/chunks/[root-of-the-server]__414ba74a._.js")
R.c("server/chunks/node_modules_ae5569c2._.js")
R.c("server/chunks/[root-of-the-server]__12aa6849._.js")
R.c("server/chunks/[root-of-the-server]__c97961e4._.js")
R.m(14765)
R.m(20685)
module.exports=R.m(20685).exports
