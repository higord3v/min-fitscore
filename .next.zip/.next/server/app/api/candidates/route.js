var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/candidates/route.js")
R.c("server/chunks/[root-of-the-server]__c974bb84._.js")
R.c("server/chunks/node_modules_ae5569c2._.js")
R.c("server/chunks/[root-of-the-server]__12aa6849._.js")
R.c("server/chunks/[root-of-the-server]__c97961e4._.js")
R.m(44812)
R.m(32411)
module.exports=R.m(32411).exports
