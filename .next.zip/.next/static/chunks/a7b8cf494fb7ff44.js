__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/e777d62c26e8b7ba.js",
  "static/chunks/turbopack-a6da0b3d7eff9032.js"
])
