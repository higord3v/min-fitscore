__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/e777d62c26e8b7ba.js",
  "static/chunks/turbopack-76bc3195865d0f89.js"
])
